<script>
	// @ts-nocheck

	// import the client instance (create earlier)
	import { supabase } from '$lib/supabse.js';

	// get data returned during page load
	export let data;

	// get data
	let student = data.student;
	let room = data.room;
	let locationevents = data.locationevents;

	// Request Supabase to select * from locationevents where student_id = filter_id
	async function filterByStudent(filter_id = 0) {
		// a variable for supabase results
		let filtered = [];

		// if param value > 0 then get locationevents for the student selected
		// select * from locationevents where student_id = filtered_id
		if (filter_id > 0) {
			filtered = await supabase.from('locationevents').select('*').eq('student_id', filter_id);
		}  
        else {
			// if filter_id = 0 get all events
			filtered = await supabase.from('locationevents').select('*');
		}

		// set locationevents to the filtered data
		locationevents = filtered.data;
	}

    // Request Supabase to select * from locationevents where building_id = filter_id
	async function filterByRoom(filter_id = 0) {
		// a variable for supabase results
		let filtered = [];
       
		// if param value > 0 then get locationevents for the student selected
		// select * from locationevents where building_id = filtered_id
		if (filter_id > 0) {
			filtered = await supabase.from('locationevents').select('*').eq('room_id', filter_id);
		} else {
			// if filter_id = 0 get all events
			filtered = await supabase.from('locationevents').select('*');
		}

		// set locationevents to the filtered data
		locationevents = filtered.data;
        
        
	}

</script>

<div class="container">
	<div>
		<!-- Page Header-->
		<h2 class="at-5">Location events from Supabase</h2>
	</div>

	<div class="row">
		<div class="col-sm-2">
			<div id="student" class="list-group">
				<button on:click={filterByStudent} class="list-group-item list-group-item-action">
					All Student
				</button>
				{#each student as students}
					<button
						on:click={() => {
							filterByStudent(Number(students.student_id));
						}}
						class="list-group-item list-group-item-action">{students.student_num}</button
					>
				{/each}
			</div>
		</div>
		<!-- End student col-->

		<div class="col-sm-2">
			<div id="room" class="list-group">
				<button on:click={filterByRoom} class="list-group-item list-group-item-action">All Rooms</button>
				{#each room as rooms}
					<button on:click={() => {
                        filterByRoom(Number(rooms.room_id));
                    }} 
                    class="list-group-item list-group-item-action">{rooms.room_num}</button>
				{/each}
			</div>
		</div>
		<!-- End building col-->

		<div class="col-sm-8">
			<!-- Page Body Right Side (Content goes here)-->
			<div id="locationevents">
				<table class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>Event id</th>
							<th>Student id</th>
							<th>Room id</th>
							<th>Event Time</th>
							<th>Event Type</th>
							<th>Event Status</th>
						</tr>
					</thead>
					<tbody>
						{#each locationevents as locationevent}
							<tr>
								<td>{locationevent.event_id}</td>
								<td>{locationevent.student_id}</td>
								<td>{locationevent.room_id}</td>
								<td>{locationevent.event_time}</td>
								<td>{locationevent.event_type}</td>
								<td>{locationevent.event_status} </td>
							</tr>
						{/each}
					</tbody>
				</table>
			</div>
		</div>
	</div>

	<!-- End of event row-->
</div>
<!-- End Main Content -->
