// import the client instance (create earlier)
import { supabase } from '$lib/supabse.js';

// The load function is executed when the page is loaded
// Here it is used to get data for display

export async function load({ fetch, params}) {
    // request supabase client to select * from student 
    const student = await supabase.from('student').select('*');

    // request supabase client to select * from  building 
    const room = await supabase.from('room').select('*');

    // request supabase client to select * from locationevents 
    const locationevents = await supabase.from('locationevents').select('*');

    // return data
    if (student && room && locationevents) {
        return {
            student: student.data,
            room: room.data,
            locationevents: locationevents.data
        };
    }

    // in case of errors - return status code and message 
    return {
        error: 'error occured'
    };
}