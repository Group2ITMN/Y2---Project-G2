
<script>

    let message = 'Welcome';
    
</script>


<h1>{message} to Tud Building Selection</h1>


 <!-- Contact Section -->
 <section id="contact" style="display: flex;">
    <h2>Submit Your Details</h2>
    <br>
    <form id="booking-form" action="#" method="POST" style="background-color: teal;"  >
        <label for="name">Student Id:</label> 
        <input type="text" id="name" name="name" >
        
        
        <label for="student_num">Student Number:</label>
        <input type="text" id="student_num" name="student_num" >
        
        <label for="first_name">First Name:</label>
        <input type="first_name" id="first_name" name="first_name" >
        
        <label for="last_name">Last Name:</label>
        <input type="text" id="last_name" name="last_name" >

        <label for="programme">Programme:</label>
        <input type="text" id="programme" name="programme" >
        
        <label for="contact">Contact:</label>
        <input type="text" id="contact" name="contact" >
        
        <label for="campus">Campus Type:</label>
        <select id="campus" name="campus" >
            <option value="blanchardstown">Blanchardstown</option>
            <option value="aungier street">Aungier Street</option>
            <option value="tallaght">Tallaght</option>
            <option value="grangegorman">Grangegorman</option>
        </select>

        <button type="submit">Submit</button>
    </form>
</section>
