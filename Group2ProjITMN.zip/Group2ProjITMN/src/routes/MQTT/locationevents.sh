#!/bin/bash

# this will be appended to the SUPABSE_URL
SUPABASE_URL="https://bmxfdjlnzirmhwsmjirt.supabase.co"
SUPABASE_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJteGZkamxuemlybWh3c21qaXJ0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDA1NzU1NTEsImV4cCI6MjA1NjE1MTU1MX0.TdfbgPDvcluBzUsOeDRd5YUVn1YhsJ1ddWbDYPBzdo8"
# the API endpoint for ac
API_ENDPOINT="/rest/v1/locationevents"
#locationevents

# HTTP Header parameters
# Data will be JSON
REQ_HEADER="Content-type: application/json"

# Saving data to API via Post request
REQ_METHOD="POST"



BRK=localhost
TOPIC=/group2proj/location


echo mosquitto_pub -h $BRK -t $TOPIC/ -m "5,102,1,15:15:00,16:15:00,Active,Present,100,GYM""
echo 'start here'"




mosquitto_sub -v -h $BRK -t $TOPIC/# | while read line
do
        #first all we do is echo the linw (topic message) to the screem
        echo ""

        echo "Third MSG received is Location Events : " $line

        echo""

        msg=$(echo $line |cut -f2- -d' ')



        location_id=$(echo $msg | cut -f1 -d',')
        echo location id: $location_id

        student_id=$(echo $msg |cut -f2 -d',')

        echo "Third MSG received is Location Events : " $line

        echo""

        msg=$(echo $line |cut -f2- -d' ')



        location_id=$(echo $msg | cut -f1 -d',')
        echo location id: $location_id

        student_id=$(echo $msg |cut -f2 -d',')

        echo student id: $student_id

        building_id=$(echo $msg | cut -f3 -d',')

        echo building id: $building_id 

        start_session=$(echo $msg  |cut -f4 -d',')

        echo the start session is: $start_session

        end_session=$(echo $msg |cut -f5 -d',')

        echo the end session is: $end_session

        room_status=$(echo $msg | cut -f6 -d',')
        echo status type: $room_status

        attendance=$(echo $msg | cut -f7 -d',')
        echo assignment: $attendance

        room_num=$(echo $msg  |cut -f8 -d',')

        echo room is:$room_num

        event_type=$(echo $msg |cut -f9 -d',')

        echo the event type is: $event_type


        # add the location event to DB
        #
        # DATA TO BE SEND IN JSON FORNAT

        JSON='{
           "location_id": "'"$location_id"'",
           "student_id": "'"$student_id"'",
           "building_id": "'"$building_id"'",
           "start_session": "'"$start_session"'",
           "end_session": "'"$end_session"'",
           "room_status": "'"$room_status"'",
           "attendance": "'"$attendance"'",
           "room_num": "'"$room_num"'",
           "event_type": "'"$event_type"'"}'


          # https://askubuntu.com/questions/1162945/how-to-send-json-as-variable-with-bash-curl

        # echo to check that it looks correct
        echo $JSON

        # Use CURL to send POST request + data
        response=$(curl -X  $REQ_METHOD $SUPABASE_URL$API_ENDPOINT -H "apikey: $SUPABASE_KEY" -H "Authorization: Bearer $SUPABASE_KEY" -H "$REQ_HEADER" -d "$JSON")

        # Show response
        echo $response



done