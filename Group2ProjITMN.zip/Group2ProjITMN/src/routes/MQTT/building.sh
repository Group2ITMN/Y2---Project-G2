 #Building 

BRK=localhost
TOPIC=/group2proj/building

echo "mosquitto_pub -h $BRK -t $TOPIC/ -m "5,Main Building, Old Blessington Road Belgard Road,Tallaght,Dublin,Ireland""
echo "check the first terminal and your database for results"

echo 'starting...'



mosquitto_sub -v -h $BRK -t $TOPIC/# | while read line
do
        #first all we do is echo the linw (topic message) to the screem
        echo ""

        echo "Second MSG received is Building Information : " $line 

        echo"" 

        msg=$(echo $line |cut -f2- -d' ')

        building_id=$(echo $msg | cut -f1 -d',')
        echo building_id: $building_id

        name=$(echo $msg |cut -f2 -d',')

        echo name of building: $name 

        address=$(echo $msg |cut -f3 -d',')
        
        echo building address: $address 

        campus=$(echo $msg  |cut -f4 -d',')

        echo name of campus: $campus 

        city=$(echo $msg |cut -f5 -d',')

        echo city:$city

        country=$(echo $msg  |cut -f6 -d',')

        echo country:$country

    


done

