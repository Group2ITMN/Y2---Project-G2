

# this will be appended to the SUPABSE_URL
SUPABASE_URL="https://bmxfdjlnzirmhwsmjirt.supabase.co"
SUPABASE_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJteGZkamxuemlybWh3c21qaXJ0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDA1NzU1NTEsImV4cCI6MjA1NjE1MTU1MX0.TdfbgPDvcluBzUsOeDRd5YUVn1YhsJ1ddWbDYPBzdo8"
# the API endpoint for ac
API_ENDPOINT="/rest/v1/locationevents"
#locationevents

# HTTP Header parameters
# Data will be JSON
REQ_HEADER="Content-type: application/json"

# Saving data to API via Post request
REQ_METHOD="POST"
#Student

BRK=localhost
TOPIC=/group2proj/student

mosquitto_sub -v -h $BRK -t $TOPIC/# | while read line
do
        #first all we do is echo the linw (topic message) to the screem
        echo ""

        echo "First MSG received is Student Information : " $line 

        echo"" 

        msg=$(echo $line |cut -f2- -d' ')


        # STUDENT 
        student_id=$(echo $msg |cut -f1 -d',')

        echo student id: $student_id 

        student_num=$(echo $msg |cut -f2 -d',')

        
        
        echo student number: $student_num 

        first_name=$(echo $msg  |cut -f3 -d',')

        echo first name: $first_name 

        last_name=$(echo $msg |cut -f4 -d',')

        echo last name:$last_name 

        programme=$(echo $msg  |cut -f5 -d',')

        echo programme:$programme 

        contact=$(echo $msg  |cut -f6 -d',')

        echo contact: $contact 


         JSON='{
        "student_id"  :"'"$student_id"'",
        "student_num" :"'"$student_num"'",
        "first_name"  :"'"$first_name"'",
        "last_name"   :"'"$last_name"'",
        "programme"    :"'"$programme"'",
        "contact"     :"'"$contact"'"}'


         # https://askubuntu.com/questions/1162945/how-to-send-json-as-variable-with-bash-curl

        # echo to check that it looks correct
        echo $JSON

        # Use CURL to send POST request + data
        response=$(curl -X  $REQ_METHOD $SUPABASE_URL$API_ENDPOINT -H "apikey: $SUPABASE_KEY" -H "Authorization: Bearer $SUPABASE_KEY" -H "$REQ_HEADER" -d "$JSON")

        # Show response
        echo $response



        
        

done